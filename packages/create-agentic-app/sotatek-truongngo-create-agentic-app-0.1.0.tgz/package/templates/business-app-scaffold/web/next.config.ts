import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  transpilePackages: ["@sotatek-truongngo/agentic-core-react"],
};

export default nextConfig;
